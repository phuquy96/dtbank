# 🏦 ĐTBank Mobile - iOS App (C++ & Objective-C++)

Dự án ứng dụng iOS **ĐTBank Mobile** với giao diện **Dark Mode Fintech** sang trọng, biểu tượng logo độc quyền và logic quản lý slide onboarding viết bằng **C++ (C++17)** kết hợp **Objective-C++**.

## 🚀 Tính năng nổi bật
* **Ngôn ngữ:** C++17 (`std::vector`, `std::string`) quản lý dữ liệu nghiệp vụ slide, kết hợp Objective-C++ UIKit giao diện native.
* **Giao diện:** Dark Mode (nền than tím huyền bí `#0A0812`), hiệu ứng phân đoạn tiến trình (segmented progress bar) ở trên cùng, lướt ngang mượt mà, nút hành động tím neon bo góc.
* **Icon & Assets:** Logo ĐTBank Dark Glassmorphism 3D chất lượng cao cùng các hình ảnh minh hoạ 3D tài chính.
* **Tự động build IPA:** Tích hợp sẵn workflow GitHub Actions (`.github/workflows/build.yml`), chỉ cần đẩy mã nguồn lên GitHub là tự động nhận file `DTBank.ipa`.

## 📦 Cách lấy file IPA từ GitHub
1. Tạo một repository mới trên GitHub (public hoặc private).
2. Tải toàn bộ nội dung trong thư mục này lên GitHub (hoặc giải nén từ file `ĐTBank.zip`).
3. Vào tab **Actions** trên GitHub, workflow `Build DTBank IPA` sẽ tự động chạy trong khoảng 2-3 phút.
4. Sau khi hoàn thành, tải file `DTBank-IPA.zip` (bên trong chứa `DTBank.ipa`) ở mục **Artifacts**.
5. Cài đặt trực tiếp lên iPhone thông qua **TrollStore, ESign, Scarlet, AltStore hoặc Sideloadly**.
