#import "OnboardingViewController.h"
#import "SlideModel.hpp"

@interface OnboardingViewController ()
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIStackView *progressStackView;
@property (nonatomic, strong) NSMutableArray<UIView *> *progressBars;
@property (nonatomic, strong) UIButton *experienceButton;
@property (nonatomic, assign) NSInteger currentIndex;
@end

@implementation OnboardingViewController {
    std::vector<SlideItem> _slides;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Nạp dữ liệu slides từ C++ Model
    _slides = SlideRepository::getSlides();
    _progressBars = [NSMutableArray array];
    _currentIndex = 0;
    
    [self setupDarkGradientBackground];
    [self setupScrollView];
    [self setupTopProgressBars];
    [self setupExperienceButton];
    [self renderSlidesContent];
    [self updateProgressHighlight:0];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (void)setupDarkGradientBackground {
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = [UIScreen mainScreen].bounds;
    // Phong cách Dark Mode đặc trưng cho ĐTBank: Đen than kết hợp tím huyền bí
    gradient.colors = @[
        (id)[UIColor colorWithRed:10.0/255.0 green:8.0/255.0 blue:18.0/255.0 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:20.0/255.0 green:16.0/255.0 blue:35.0/255.0 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:12.0/255.0 green:10.0/255.0 blue:22.0/255.0 alpha:1.0].CGColor
    ];
    gradient.locations = @[@0.0, @0.6, @1.0];
    gradient.startPoint = CGPointMake(0.5, 0.0);
    gradient.endPoint = CGPointMake(0.5, 1.0);
    [self.view.layer insertSublayer:gradient atIndex:0];
}

- (void)setupTopProgressBars {
    self.progressStackView = [[UIStackView alloc] init];
    self.progressStackView.axis = UILayoutConstraintAxisHorizontal;
    self.progressStackView.distribution = UIStackViewDistributionFillEqually;
    self.progressStackView.spacing = 6.0;
    self.progressStackView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.progressStackView];

    [NSLayoutConstraint activateConstraints:@[
        [self.progressStackView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:10],
        [self.progressStackView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:18],
        [self.progressStackView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-18],
        [self.progressStackView.heightAnchor constraintEqualToConstant:3.5]
    ]];

    for (size_t i = 0; i < _slides.size(); ++i) {
        UIView *segment = [[UIView alloc] init];
        segment.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.18];
        segment.layer.cornerRadius = 1.75;
        segment.clipsToBounds = YES;
        [self.progressStackView addArrangedSubview:segment];
        [self.progressBars addObject:segment];
    }
}

- (void)setupScrollView {
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.bounces = NO;
    self.scrollView.delegate = self;
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.scrollView];
}

- (void)setupExperienceButton {
    self.experienceButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.experienceButton setTitle:@"Trải nghiệm ngay" forState:UIControlStateNormal];
    [self.experienceButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.experienceButton.titleLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightBold];
    
    // Màu tím neon đặc trưng của ĐTBank
    self.experienceButton.backgroundColor = [UIColor colorWithRed:142.0/255.0 green:68.0/255.0 blue:230.0/255.0 alpha:1.0];
    self.experienceButton.layer.cornerRadius = 25.0;
    self.experienceButton.layer.shadowColor = [UIColor colorWithRed:155.0/255.0 green:80.0/255.0 blue:245.0/255.0 alpha:0.5].CGColor;
    self.experienceButton.layer.shadowOffset = CGSizeMake(0, 6);
    self.experienceButton.layer.shadowOpacity = 0.9;
    self.experienceButton.layer.shadowRadius = 14;
    self.experienceButton.translatesAutoresizingMaskIntoConstraints = NO;

    [self.experienceButton addTarget:self action:@selector(handleExperienceTap) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.experienceButton];

    [NSLayoutConstraint activateConstraints:@[
        [self.experienceButton.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-22],
        [self.experienceButton.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:24],
        [self.experienceButton.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-24],
        [self.experienceButton.heightAnchor constraintEqualToConstant:50]
    ]];
}

- (void)renderSlidesContent {
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    self.scrollView.contentSize = CGSizeMake(screenWidth * _slides.size(), screenHeight);

    NSBundle *bundle = [NSBundle mainBundle];

    for (size_t i = 0; i < _slides.size(); ++i) {
        const auto &slide = _slides[i];
        UIView *slideView = [[UIView alloc] initWithFrame:CGRectMake(i * screenWidth, 0, screenWidth, screenHeight)];

        // Khối ảnh minh hoạ 3D Dark Mode
        CGFloat imgSize = screenWidth * 0.76;
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((screenWidth - imgSize) / 2.0, screenHeight * 0.16, imgSize, imgSize)];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        imageView.clipsToBounds = YES;
        imageView.layer.cornerRadius = 24.0;
        
        NSString *imageFile = [NSString stringWithUTF8String:slide.imageName.c_str()];
        NSString *imagePath = [bundle pathForResource:imageFile ofType:nil inDirectory:@"Resources"];
        if (!imagePath) {
            imagePath = [bundle pathForResource:imageFile ofType:nil];
        }
        if (imagePath) {
            imageView.image = [UIImage imageWithContentsOfFile:imagePath];
        } else {
            // Fallback icon logo
            NSString *logoPath = [bundle pathForResource:@"icon_src" ofType:@"png" inDirectory:@"Resources"];
            if (logoPath) imageView.image = [UIImage imageWithContentsOfFile:logoPath];
        }
        [slideView addSubview:imageView];

        // Tiêu đề phụ (Subtitle)
        UILabel *subLabel = [[UILabel alloc] initWithFrame:CGRectMake(24, screenHeight * 0.65, screenWidth - 48, 24)];
        subLabel.text = [NSString stringWithUTF8String:slide.subtitle.c_str()];
        subLabel.textColor = [UIColor colorWithRed:175.0/255.0 green:175.0/255.0 blue:200.0/255.0 alpha:1.0];
        subLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
        subLabel.textAlignment = NSTextAlignmentCenter;
        [slideView addSubview:subLabel];

        // Tiêu đề chính (Title)
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(24, screenHeight * 0.69, screenWidth - 48, 64)];
        titleLabel.text = [NSString stringWithUTF8String:slide.title.c_str()];
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.numberOfLines = 2;
        [slideView addSubview:titleLabel];

        [self.scrollView addSubview:slideView];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGFloat pageWidth = scrollView.bounds.size.width;
    if (pageWidth > 0) {
        NSInteger page = (NSInteger)round(scrollView.contentOffset.x / pageWidth);
        if (page != self.currentIndex && page >= 0 && page < (NSInteger)_slides.size()) {
            self.currentIndex = page;
            [self updateProgressHighlight:page];
        }
    }
}

- (void)updateProgressHighlight:(NSInteger)activeIndex {
    for (NSInteger i = 0; i < (NSInteger)self.progressBars.count; ++i) {
        UIView *bar = self.progressBars[i];
        [UIView animateWithDuration:0.25 animations:^{
            if (i == activeIndex) {
                bar.backgroundColor = [UIColor colorWithRed:168.0/255.0 green:85.0/255.0 blue:247.0/255.0 alpha:1.0];
            } else if (i < activeIndex) {
                bar.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.45];
            } else {
                bar.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.18];
            }
        }];
    }
}

- (void)handleExperienceTap {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Chào mừng bạn đến với ĐTBank"
                                                                   message:@"Bạn đã sẵn sàng trải nghiệm các tiện ích tài chính đỉnh cao!"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Bắt đầu ngay" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
