#import <UIKit/UIKit.h>

@interface OnboardingViewController : UIViewController <UIScrollViewDelegate>
@end
