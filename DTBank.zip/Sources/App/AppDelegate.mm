#import "AppDelegate.h"
#import "OnboardingViewController.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor colorWithRed:10.0/255.0 green:8.0/255.0 blue:18.0/255.0 alpha:1.0];
    
    OnboardingViewController *rootVC = [[OnboardingViewController alloc] init];
    self.window.rootViewController = rootVC;
    [self.window makeKeyAndVisible];
    
    return YES;
}

@end
