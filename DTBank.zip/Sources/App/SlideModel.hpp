#pragma once
#include <string>
#include <vector>

struct SlideItem {
    std::string title;
    std::string subtitle;
    std::string imageName;
};

class SlideRepository {
public:
    static std::vector<SlideItem> getSlides();
};
