#include "SlideModel.hpp"

std::vector<SlideItem> SlideRepository::getSlides() {
    return {
        {
            "TIỆN ÍCH ĐỈNH, SỐNG ĐỈNH",
            "Chào mừng bạn đến với ĐTBank!",
            "slide_bank.jpg"
        },
        {
            "TÀI KHOẢN NICKNAME ĐỘC ĐÁO\nHOẶC TÀI KHOẢN SỐ ĐẸP MIỄN PHÍ",
            "Thỏa sức tạo dấu ấn riêng với ĐTBank",
            "slide_card.jpg"
        },
        {
            "CHUYỂN TIỀN Y NHƯ CHAT",
            "Chuyển tiền giờ đây dễ như nhắn tin!",
            "slide_bank.jpg"
        },
        {
            "THANH TOÁN MỌI NHU CẦU",
            "Hàng ngàn dịch vụ: Viễn thông, giải trí, du lịch, mua sắm...",
            "slide_card.jpg"
        },
        {
            "HÀNG NGÀN ƯU ĐÃI HẤP DẪN",
            "Mua sắm hoàn tiền lên đến 30%\nCác chương trình quay thưởng quanh năm",
            "slide_bank.jpg"
        },
        {
            "TRỢ LÝ TÀI CHÍNH THÔNG MINH",
            "Cần lúc bạn khó, có lúc bạn cần!",
            "slide_card.jpg"
        },
        {
            "MỞ THẺ TÍN DỤNG ONLINE",
            "Không cần chứng minh thu nhập\nThủ tục online 100%!",
            "slide_card.jpg"
        }
    };
}
